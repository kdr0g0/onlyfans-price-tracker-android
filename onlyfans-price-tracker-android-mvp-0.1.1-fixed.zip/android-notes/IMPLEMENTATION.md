# Android background and collection implementation notes

## Background checks

The next native layer should implement a Capacitor plugin backed by Android WorkManager:
- enqueue unique periodic work;
- interval selected in the app, default 3 hours;
- cancel/reschedule when the setting changes;
- only process active profiles;
- record `lastAttemptAt`, `lastSuccessAt`, and explicit error categories;
- obey connectivity and battery constraints;
- avoid claiming exact execution time.

Android WorkManager periodic tasks have a 15-minute minimum interval, but execution is inexact and can be delayed by Doze, battery optimization, connectivity, and OS scheduling.

## Collection constraints

Do not treat the embedded WebView as sharing Chrome's login session. The prototype performs unauthenticated HTTP requests only and doesn't store cookies. If OnlyFans requires an authenticated session or blocks requests, report that status. Do not infer a price from arbitrary visible text or a failed response.

## Graph semantics

Store each observation independently. A missing `promo` value is `null`, not zero. Chart lines must use `connectNulls=false`. A failed check should be recorded as a check event but should not be represented as a price point.
