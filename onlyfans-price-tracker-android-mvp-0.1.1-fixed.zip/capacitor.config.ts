import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.personal.onlyfanspricetracker',
  appName: 'OF Price Tracker',
  webDir: 'dist',
  bundledWebRuntime: false,
  plugins: { CapacitorHttp: { enabled: true } }
};
export default config;
