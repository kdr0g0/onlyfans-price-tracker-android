# OnlyFans Price Tracker — Android MVP 0.1.0

Prototype source for a native Android wrapper built with React + TypeScript + Capacitor. The UI is Hebrew/RTL, stores data locally, has profile tracking, one combined chart, an internal alerts screen, JSON export, and a configurable default check interval of 3 hours for all tracked profiles.

## Honest status

- This is source code, not a compiled APK.
- The public-profile collector is an **experimental proof-of-feasibility**. It attempts an unauthenticated HTTP GET and only accepts explicitly named `subscribePrice` / `subscriptionPrice` fields. It never invents a price and never reads Chrome cookies or credentials.
- A successful page request does not prove that all OnlyFans profile prices or logged-in promotions are accessible. The current collector does **not** collect authenticated promotions.
- The current interval timer works while the app process is active. It is **not yet a true Android background scheduler**. WorkManager integration is required for periodic background execution, and Android may defer execution.
- The graph leaves gaps when observations have no promo value (`connectNulls={false}`).
- The app does not call a paid server and does not send saved data off-device.

## Requirements

Node.js 20+, Android Studio / Android SDK, Java compatible with your installed Android Gradle plugin.

## Run the web preview

```bash
npm install
npm run dev
```

## Create the Android project

```bash
npm install
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

Then build/run from Android Studio. The Capacitor Android platform is generated locally by `cap add android`.

## Next implementation tasks

1. Test the public profile request against real profiles on a device and inspect whether stable, explicitly named price fields are available.
2. Implement a custom Capacitor plugin backed by Android WorkManager for the selected interval. Keep the interval setting user-editable; default 3 hours.
3. Add a supported and reliable way to capture a price the user actually sees in a logged-in session. Do not copy cookies/tokens into a server.
4. Validate that missing promo observations create gaps and never imply a promo was available continuously.
5. Add database migration/export/import and tests.

## Privacy

Local profile list and observations are stored using Capacitor Preferences. No password, cookies, authentication headers, or private subscriber data are saved or transmitted by this prototype.
