import React from 'react';
import { createRoot } from 'react-dom/client';
import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';
import { CapacitorHttp } from '@capacitor-community/http';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Line, LineChart } from 'recharts';
import { Activity, Bell, Clock3, Download, ExternalLink, Plus, RefreshCw, Settings, Trash2, UserRound, CheckCircle2, AlertTriangle, CircleHelp } from 'lucide-react';
import './style.css';

type Observation = { id:string; at:string; regular:number|null; promo:number|null; source:string; status:'ok'|'failed'; note?:string };
type Profile = { id:string; username:string; url:string; active:boolean; observations:Observation[]; lastStatus?:string };
type Store = { profiles:Profile[]; intervalHours:number; autoCheck:boolean; activeTab:'home'|'alerts'|'settings' };
const KEY='ofpt-store-v1';
const defaultStore:Store={profiles:[],intervalHours:3,autoCheck:true,activeTab:'home'};
const money=(n:number|null|undefined)=>n==null?'—':new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
const dateLabel=(s:string)=>new Date(s).toLocaleString('he-IL',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
function App(){
 const [store,setStore]=React.useState<Store>(defaultStore);
 const [ready,setReady]=React.useState(false);
 const [newUser,setNewUser]=React.useState('');
 const [busy,setBusy]=React.useState<string|null>(null);
 const [message,setMessage]=React.useState('המידע נשמר במכשיר זה.');
 const [selected,setSelected]=React.useState<string|null>(null);
 React.useEffect(()=>{(async()=>{try{const r=await Preferences.get({key:KEY}); if(r.value)setStore({...defaultStore,...JSON.parse(r.value)});}catch{const raw=localStorage.getItem(KEY);if(raw)setStore({...defaultStore,...JSON.parse(raw)});}setReady(true)})()},[]);
 React.useEffect(()=>{if(!ready)return; const raw=JSON.stringify(store); Preferences.set({key:KEY,value:raw}).catch(()=>localStorage.setItem(KEY,raw));},[store,ready]);
 const allObs=store.profiles.flatMap(p=>p.observations.map(o=>({...o,username:p.username})));
 const alerts=allObs.filter(o=>o.status==='failed').slice().reverse();
 const addProfile=()=>{
   let input=newUser.trim().replace(/^@/,''); if(!input)return;
   let username=input;
   try{const u=new URL(input.startsWith('http')?input:'https://onlyfans.com/'+input); if(u.hostname!=='onlyfans.com'&&!u.hostname.endsWith('.onlyfans.com'))throw Error(); username=u.pathname.split('/').filter(Boolean)[0]||'';}catch{setMessage('הזן שם משתמש או קישור תקין של onlyfans.com');return}
   if(!/^[a-zA-Z0-9_.-]{1,80}$/.test(username)){setMessage('שם המשתמש אינו תקין');return}
   if(store.profiles.some(p=>p.username.toLowerCase()===username.toLowerCase())){setMessage('הפרופיל כבר נמצא במעקב');return}
   setStore(s=>({...s,profiles:[{id:crypto.randomUUID(),username,url:'https://onlyfans.com/'+username,active:true,observations:[]},...s.profiles]})); setNewUser('');setMessage('הפרופיל נוסף. ניתן לנסות בדיקה עכשיו.');
 };
 const updateProfile=(id:string,fn:(p:Profile)=>Profile)=>setStore(s=>({...s,profiles:s.profiles.map(p=>p.id===id?fn(p):p)}));
 const addObservation=(id:string,obs:Observation)=>updateProfile(id,p=>({...p,observations:[...p.observations,obs],lastStatus:obs.status}));
 // This collector is intentionally conservative: it tests an unauthenticated public profile request only.
 // It does not copy browser cookies, passwords, or authenticated sessions.
 const checkProfile=async(p:Profile)=>{
   setBusy(p.id);setMessage('בודק גישה ציבורית לפרופיל…');
   const now=new Date().toISOString(); let obs:Observation;
   try {
     let response:any;
     if(Capacitor.isNativePlatform()){
       response=await CapacitorHttp.get({url:p.url,headers:{'Accept':'text/html,application/xhtml+xml'},connectTimeout:12000,readTimeout:12000});
     } else {
       response=await fetch(p.url,{method:'GET',credentials:'omit',redirect:'follow'});
     }
     const status=Number(response.status||0);
     const html=String(response.data??response.body??'');
     // Only accept explicitly identified price fields; never guess a price from arbitrary page text.
     const patterns=[/(?:\"subscribePrice\"|subscribePrice)\s*:\s*(\d+(?:\.\d+)?)/i,/(?:\"subscriptionPrice\"|subscriptionPrice)\s*:\s*(\d+(?:\.\d+)?)/i];
     let regular:number|null=null;
     if(status>=200&&status<300){
       for(const re of patterns){const m=html.match(re);if(m){const v=Number(m[1]);if(Number.isFinite(v)&&v>=0&&v<100000){regular=v;break;}}}
     }
     if(status>=200&&status<300&&regular!==null){
       obs={id:crypto.randomUUID(),at:now,regular,promo:null,source:'public-profile-http',status:'ok',note:'נמצא מחיר רגיל בשדה מזוהה; מחיר מבצע לא נבדק במנגנון זה.'};
       setMessage('הבדיקה הצליחה: נמצא מחיר רגיל. מבצעים מחוברים עדיין לא נאספים.');
     } else {
       obs={id:crypto.randomUUID(),at:now,regular:null,promo:null,source:'public-profile-http',status:'failed',note:status===401||status===403?'הגישה דורשת הרשאה או נחסמה.':status>=200&&status<300?'הדף נטען אך לא נמצא שדה מחיר מוכר.':'HTTP '+status};
       setMessage('לא התקבלה תצפית מחיר מאומתת. לא נשמר מחיר משוער.');
     }
   } catch(e:any) {
     obs={id:crypto.randomUUID(),at:now,regular:null,promo:null,source:'public-profile-http',status:'failed',note:'הגישה הציבורית נכשלה או נחסמה (ייתכן CORS, חיבור או חסימת אתר).'};
     setMessage('הבדיקה נכשלה: '+obs.note);
   }
   addObservation(p.id,obs);setBusy(null);
 };
 const runAll=async()=>{for(const p of store.profiles.filter(p=>p.active)){await checkProfile(p)}};
 React.useEffect(()=>{
   if(!ready||!store.autoCheck||store.intervalHours<1)return;
   // Foreground timer only. True periodic background work requires a native WorkManager plugin.
   const ms=store.intervalHours*3600000;
   const timer=window.setInterval(()=>{runAll()},ms);
   return()=>window.clearInterval(timer);
 },[ready,store.autoCheck,store.intervalHours,store.profiles.map(p=>p.id+':'+p.active).join('|')]);
 const exportData=()=>{
   const blob=new Blob([JSON.stringify({...store,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});
   const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='of-price-tracker-backup.json';a.click();URL.revokeObjectURL(url);
 };
 const removeProfile=(id:string)=>{if(confirm('להסיר את הפרופיל ואת היסטוריית המחירים מהמכשיר?'))setStore(s=>({...s,profiles:s.profiles.filter(p=>p.id!==id)}))};
 const current=store.profiles.find(p=>p.id===selected);
 const currentRows=current?.observations.map(o=>({...o,time:dateLabel(o.at)}))||[];
 return <div className="app-shell">
  <header className="topbar"><div className="brand"><div className="brand-icon"><Activity size={22}/></div><div><b>Price Tracker</b><small>OnlyFans · Android</small></div></div><button className="icon-button" onClick={()=>setStore(s=>({...s,activeTab:'settings'}))} aria-label="הגדרות"><Settings/></button></header>
  <main>
   {store.activeTab==='home'&&<><section className="hero"><div><div className="eyebrow">מעקב מחירים אישי</div><h1>היסטוריית מחירים<br/>בלי ניחושים.</h1><p>תצפיות אמיתיות בלבד. אין קו מבצע כשאין נתון.</p></div><div className="hero-mark"><Activity size={44}/></div></section>
    <section className="stats"><div className="stat"><span>פרופילים במעקב</span><strong>{store.profiles.length}</strong></div><div className="stat"><span>תצפיות שמורות</span><strong>{allObs.filter(o=>o.status==='ok').length}</strong></div><div className="stat"><span>תדירות</span><strong>{store.intervalHours} ש׳</strong></div></section>
    <section className="section-head"><div><h2>הפרופילים שלי</h2><p>הוסף פרופיל כדי להתחיל</p></div></section>
    <form className="add-form" onSubmit={e=>{e.preventDefault();addProfile()}}><input value={newUser} onChange={e=>setNewUser(e.target.value)} placeholder="שם משתמש או קישור OnlyFans" aria-label="שם משתמש או קישור"/><button className="primary" type="submit"><Plus size={18}/> הוסף</button></form>
    <div className="notice"><CircleHelp size={18}/><span>{message}</span></div>
    {store.profiles.length===0?<div className="empty"><UserRound size={32}/><b>עדיין אין פרופילים</b><span>הוסף שם משתמש כדי ליצור רשומת מעקב.</span></div>:<div className="profile-list">{store.profiles.map(p=><article className="profile-card" key={p.id}><div className="profile-top"><div className="avatar">{p.username.slice(0,1).toUpperCase()}</div><div className="profile-meta"><b>@{p.username}</b><small>{p.observations.length?`תצפיות: ${p.observations.length} · בדיקה אחרונה: ${dateLabel(p.observations[p.observations.length-1].at)}`:'עדיין לא נבדק'}</small></div><button className="icon-button danger" onClick={()=>removeProfile(p.id)} aria-label="הסר פרופיל"><Trash2 size={17}/></button></div><div className="price-row"><div><span>מחיר רגיל אחרון</span><strong>{money([...p.observations].reverse().find(o=>o.regular!==null)?.regular)}</strong></div><div><span>מחיר מבצע אחרון</span><strong>{money([...p.observations].reverse().find(o=>o.promo!==null)?.promo)}</strong></div></div><div className="card-actions"><button className="secondary" onClick={()=>setSelected(p.id)}>היסטוריה וגרף</button><button className="primary" disabled={busy===p.id} onClick={()=>checkProfile(p)}>{busy===p.id?<RefreshCw className="spin" size={16}/>:<RefreshCw size={16}/>} בדוק עכשיו</button></div></article>)}</div>}
   </>}
   {store.activeTab==='alerts'&&<><section className="section-head"><div><h1>התראות</h1><p>אירועים ותוצאות בדיקה שנשמרו במכשיר</p></div></section>{alerts.length===0?<div className="empty"><Bell size={30}/><b>אין התראות כרגע</b><span>כשלי בדיקה ושינויים מאומתים יופיעו כאן.</span></div>:alerts.map((a,i)=><div className="alert-row" key={a.id}><AlertTriangle/><div><b>@{a.username} — הבדיקה לא הצליחה</b><p>{a.note}</p><small>{dateLabel(a.at)}</small></div></div>)}</>}
   {store.activeTab==='settings'&&<><section className="section-head"><div><h1>הגדרות</h1><p>תזמון ואחסון מקומי</p></div></section><section className="settings-card"><label>תדירות בדיקה אוטומטית</label><select value={store.intervalHours} onChange={e=>setStore(s=>({...s,intervalHours:Number(e.target.value)}))}><option value="0.25">כל 15 דקות (מינימום תזמון Android)</option><option value="0.5">כל 30 דקות</option><option value="1">כל שעה</option><option value="3">כל 3 שעות — ברירת מחדל</option><option value="6">כל 6 שעות</option><option value="12">כל 12 שעות</option><option value="24">כל 24 שעות</option></select><label className="toggle"><span><b>בדיקות אוטומטיות</b><small>הטיימר בתוך האפליקציה פעיל רק כשהיא פתוחה; תזמון אמיתי ברקע דורש רכיב Android נוסף.</small></span><input type="checkbox" checked={store.autoCheck} onChange={e=>setStore(s=>({...s,autoCheck:e.target.checked}))}/></label><button className="secondary full" onClick={exportData}><Download size={17}/> ייצא גיבוי JSON</button><div className="privacy-note"><CheckCircle2 size={18}/><span>לא נשמרים סיסמאות, Cookies או פרטי התחברות. הנתונים נשמרים מקומית.</span></div></section></>}
   {selected&&current&&<div className="modal-backdrop" onClick={()=>setSelected(null)}><section className="history-sheet" onClick={e=>e.stopPropagation()}><div className="sheet-head"><div><small>היסטוריית פרופיל</small><h2>@{current.username}</h2></div><button className="icon-button" onClick={()=>setSelected(null)}>✕</button></div><div className="chart-legend"><span><i className="dot blue"/>מחיר רגיל</span><span><i className="dot green"/>מחיר מבצע</span></div><div className="chart-wrap">{currentRows.some(r=>r.regular!==null||r.promo!==null)?<ResponsiveContainer width="100%" height="100%"><LineChart data={currentRows}><CartesianGrid strokeDasharray="3 3" stroke="#2c3039"/><XAxis dataKey="time" tick={{fill:'#9ba2b1',fontSize:10}}/><YAxis tick={{fill:'#9ba2b1',fontSize:10}}/><Tooltip formatter={(v:any)=>money(Number(v))}/><Line type="linear" dataKey="regular" name="מחיר רגיל" stroke="#6d9cff" strokeWidth={2.5} dot={{r:3}} connectNulls={false} isAnimationActive={false}/><Line type="linear" dataKey="promo" name="מחיר מבצע" stroke="#35c78a" strokeWidth={2.5} dot={{r:4}} connectNulls={false} isAnimationActive={false}/></LineChart></ResponsiveContainer>:<div className="empty compact">אין עדיין תצפיות מחיר מאומתות</div>}</div><div className="observation-list">{[...current.observations].reverse().map(o=><div className="obs-row" key={o.id}><div><b>{dateLabel(o.at)}</b><small>{o.status==='ok'?'תצפית':'בדיקה נכשלה'} · {o.note||o.source}</small></div><div className="obs-prices"><span>{money(o.regular)}</span><span>{money(o.promo)}</span></div></div>)}</div></section></div>}
  </main>
  <nav className="bottom-nav"><button className={store.activeTab==='home'?'active':''} onClick={()=>setStore(s=>({...s,activeTab:'home'}))}><Activity/><span>מעקב</span></button><button className={store.activeTab==='alerts'?'active':''} onClick={()=>setStore(s=>({...s,activeTab:'alerts'}))}><Bell/><span>התראות</span></button><button className={store.activeTab==='settings'?'active':''} onClick={()=>setStore(s=>({...s,activeTab:'settings'}))}><Settings/><span>הגדרות</span></button></nav>
 </div>
}
createRoot(document.getElementById('root')!).render(<App/>);
